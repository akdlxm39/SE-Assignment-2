#ifndef PROGRAM_EXIT_UI_H
#define PROGRAM_EXIT_UI_H

#include <string>

#include "fileio.h"

using namespace std;

class ProgramExitUI
{
private:

public:

	void startInterface(); // ProgramExitUI ����

};
#endif